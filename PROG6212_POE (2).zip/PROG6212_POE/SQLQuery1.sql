﻿

CREATE TABLE ModuleData(
moduleCode varchar(20) PRIMARY KEY NOT NULL,
moduleName varchar(100) NOT NULL,
classHours int NOT NULL,
selfStudyHrs int NOT NULL,
studyHrsRemaining int NOT NULL);

CREATE TABLE SemesterData(UserID int PRIMARY KEY REFERENCES Users(UserID) NOT NULL,
moduleCode varchar(20) FOREIGN KEY REFERENCES ModuleData(moduleCode) NOT NULL,
semesterStartDate	datetime NOT NULL , 
semesterWeeks int NOT NULL);



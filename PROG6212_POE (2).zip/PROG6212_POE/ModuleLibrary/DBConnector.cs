﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ModuleLibrary
{
    public class DBConnector
    {
       
        public SqlConnection MyConnection { set; get; }
        //adding the database open connection to the constructor
        public DBConnector() 
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\lab_services_student\\source\\repos\\databaseConnectionExample\\databaseConnectionExample\\Database1.mdf;Integrated Security=True;Connect Timeout=30";
            SqlConnection myConnection = new SqlConnection(connectionString);//creating a sql connection
            this.MyConnection = myConnection;

            myConnection.Open();//just opening it for now for tesing purposes

        }
        public void insertData(string username, string password)
        {

            string insertCommand = $"INSERT INTO Users(Username, Passwords) VALUES('{username}','{password}');";
            SqlCommand command = new SqlCommand(insertCommand, MyConnection);//defining the sql command 

            SqlDataAdapter adapter = new SqlDataAdapter();//creating the sql data adapter  used to create insert ,upadate and delete commands

            adapter.InsertCommand = new SqlCommand(insertCommand, MyConnection);//preparing the insert statement
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            MyConnection.Close();//closing the sql connection

        }
        public void readData()
        {
            string connectionString = "", selectCommand;
            SqlDataReader dataReader;
            SqlCommand command;
         

            selectCommand = "SELECT Username, Passwords FROM Users";//THIS SQL will only display the current registed user name and passwords

            command = new SqlCommand(selectCommand, MyConnection);
            dataReader = command.ExecuteReader();
            string output = "";
            while (dataReader.Read())
            {
                output = output + dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + "\n";
            }

           // MessageBox.Show(output);

            dataReader.Close();
            command.Dispose();
            MyConnection.Close();


        }


        public string readSemesterData(string userid)
        {
            string selectCommand;
            SqlDataReader dataReader;
            SqlCommand command;


            selectCommand = $"SELECT moduleCode, semesterStartDate, semesterWeeks FROM SemesterData WHERE UserID ='{userid}'";//THIS SQL will only display the current logged in user semester details

            command = new SqlCommand(selectCommand, MyConnection);
            dataReader = command.ExecuteReader();
            string output = "";
            while (dataReader.Read())
            {
                output = output + dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + "\n"+dataReader.GetValue(2);
            }
         

            

            dataReader.Close();
            command.Dispose();
            MyConnection.Close();

            return output;
        }

        public void insertModuleData(string moduleCode,string moduleName, double classHours, double selfStudyHrs, double studyHrsRemaining)
        {

            //insert command that will be used to insert the module     Data into the database
            string insertCommand = $"INSERT INTO ModuleData(moduleCode, moduleName, classHours, selfStudyHrs, studyHrsRemaining) VALUES('{moduleCode}','{moduleName}','{classHours}','{selfStudyHrs}','{studyHrsRemaining}');";
            SqlCommand command = new SqlCommand(insertCommand, MyConnection);//defining the sql command 

            SqlDataAdapter adapter = new SqlDataAdapter();//creating the sql data adapter  used to create insert ,upadate and delete commands

            adapter.InsertCommand = new SqlCommand(insertCommand, MyConnection);//preparing the insert statement
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            MyConnection.Close();//closing the sql connection

        }


        public void insertSemesterData(int userId, string ModuleCode, string SemesterStartDate, int weeks) 
        {

            //insert command that will be used to insert the module     Data into the database
            string insertCommand = $"INSERT INTO SemesterData(UserID, moduleCode, semesterStartDate, semesterWeeks) VALUES('{userId}','{ModuleCode}','{SemesterStartDate}','{weeks}');";
            SqlCommand command = new SqlCommand(insertCommand, MyConnection);//defining the sql command 

            SqlDataAdapter adapter = new SqlDataAdapter();//creating the sql data adapter  used to create insert ,upadate and delete commands

            adapter.InsertCommand = new SqlCommand(insertCommand, MyConnection);//preparing the insert statement
            adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            MyConnection.Close();//closing the sql connection

        }

    }
}

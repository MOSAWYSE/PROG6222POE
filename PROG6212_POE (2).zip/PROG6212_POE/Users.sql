﻿using Database1;

CREATE TABLE Users(
userID int IDENTITY(1,1) PRIMARY KEY NOT NULL,
Username varchar(100) NOT NULL,
Passwords varchar(200) NOT NULL

);
﻿using System;
using ModuleLibrary;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Security.Cryptography;
using System.Data.Common;
using System.Linq.Expressions;
using System.Security;
using System.Threading;
using System.Numerics;

namespace PROG6212_POE
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Login : Window
    {
        public int userID { get; set; }//This will be used to retrieve the logged in userID with linq
        DBConnector dBConnector = new DBConnector();
        public Login()
        {
            InitializeComponent();
            // Thread loginThread = new Thread(new ParameterizedThreadStart();
            errorMessages.Content = Visibility.Visible;




        }
        //exit button
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }



        //login button function
        private async void loginButton_Click(object sender, RoutedEventArgs e)
        {
            //creating an object of the database class

            
            MainWindow mainProgram = new MainWindow(userID);

            string username = usernameTextBox.Text;
            SecureString password = passwordTextBox.SecurePassword;//this will retrieve the password string from the password 
            string sql = $"SELECT * FROM Users WHERE Username = '{username}'"; //fix the sql statement




            //adding this here for testing purposes
            string selectCommand = $"SELECT * FROM Users WHERE Passwords ='{getHashedPassword(password.ToString())}'";

           SqlCommand command = new SqlCommand(selectCommand, dBConnector.MyConnection);
           SqlDataReader dataReader = command.ExecuteReader();
            string output = "";
            while (dataReader.Read())
            {
                //this will retrive the username
                output +=  dataReader.GetString(0);
                
              //  errorMessages.Content = $"Welcome {output} to our time system";
                MessageBox.Show($"Welcome {output} to our time system.","Welcome message");

                
            }


            dataReader.Close();
            //try block to handle the password retrieval from the database

            
            try
            {
                SqlCommand cmd = new SqlCommand(sql, dBConnector.MyConnection);//creating the sql command 
            
           

                 
                dataReader = cmd.ExecuteReader();
                    string hashedStoredPassword = "";

                        while(dataReader.Read()) 
                        { 
                         hashedStoredPassword = password.ToString() + dataReader.GetValue(0);//this will retieve the hashed password 

                      
                            string passwordConfirm = "";
                            passwordConfirm = password.ToString() + dataReader.GetValue(1);

                    //checkcing the username ane the passwrod 

                    if (string.IsNullOrEmpty(username) || password == null) { return; }
                            MessageBox.Show($"Your new hash is {getHashedPassword(password.ToString())} \n Your old stored hash is {dataReader.GetValue(0)}\nhash  {passwordConfirm}");
                           

                            

                            if (getHashedPassword(password.ToString()).Equals(passwordConfirm))
                            {

                               // MessageBox.Show("Your password is " + );
                               //errorMessages.Visibility = Visibility.Visible;
                                MessageBox.Show($"Your password is {hashedStoredPassword}", "Login Alert");
                                mainProgram.Show();
                                break;

                        // Create an instance of MainWindow and pass the userID as a parameter
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            MainWindow mainProgram = new MainWindow(userID);
                            mainProgram.Show();
                        });

                    }
                            else 
                            {
                                MessageBox.Show($"Your password is incorrect.","Login Alert");
                            }
                        //    dataReader.Close();//Closing the data reader
                        }

                    cmd.Dispose();//disposing the command //disposing the command 
                   // reader.Close();//Closing the data reader
                dataReader.Close();

               



            } catch (Exception er)
            {
                MessageBox.Show($" An error has occured >> {er.Message}");
            }
           

           

            dBConnector.MyConnection.Close();//closing the sql connection
            Thread.Sleep(1000);

        }
        //temp login action 

        private async void loginButton_Clic2k(object sender, RoutedEventArgs e)
        {
            

            string username = usernameTextBox.Text;
           // SecureString password = passwordTextBox.SecurePassword;
            string password = passwordTextBox.Password;

            // Validate the username and password
            if (string.IsNullOrEmpty(username) || password == null)
            {
              
                MessageBox.Show($"Please enter both username and password.","Login Alert");
                return;
            }
            else if(username.Length.Equals(8)) 
            {
                MessageBox.Show("User characters must not exceed 8 characters.", "Login Alert");
            }

            string hashedInputPassword = getHashedPassword(password.ToString());
            try
            {
                await Task.Run(() => {
                // Creating a DBConnector instance
                DBConnector dBConnector = new DBConnector();

                string sql = $"SELECT Passwords, userID FROM Users WHERE Username = '{username}'";

                    

                using (SqlCommand cmd = new SqlCommand(sql, dBConnector.MyConnection))
                {
                   
                    using (SqlDataReader dataReader = cmd.ExecuteReader())
                    {
                        if (dataReader.Read())
                        {
                            string hashedStoredPassword = dataReader.GetString(0);
                            int AuthenticatedUserID = dataReader.GetInt32(1);
                                //the user id is the assigned user id for the login session.
                                 userID = dataReader.GetInt32(1);
                                
                            if (userID != AuthenticatedUserID)
                            {
                                Application.Current.Dispatcher.Invoke(() =>
                                {
                                    MessageBox.Show($"You are not authenticated.", "Login Alert");
                                    return;
                                });
                                
                            }

                                dataReader.Close();

                                //using the dispatcher to handle the ui operations
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                                 //   MessageBox.Show($"Login old stored hash ={hashedStoredPassword} \nGenerated input hash: {getHashedPassword(password.ToString())}\nPassword hashed current: {getHashedPassword(password)}!");

                            if (hashedStoredPassword.Equals(getHashedPassword(password)))
                            {
                                sql = $"SELECT Username FROM Users WHERE Passwords='{getHashedPassword(password)}'";
                                using(SqlCommand command = new SqlCommand(sql, dBConnector.MyConnection)) 
                                {
                                    //executing the select username command
                                    using (SqlDataReader loginDataReader = command.ExecuteReader()) 
                                    {
                                        //checking the stored details to validate the login 
                                        if(loginDataReader.Read()) 
                                        {
                                            username  = loginDataReader.GetString(0);
                                            MessageBox.Show($"Log in was successful. Welcome {username}","Welcome Message");
                                            // Add code to open the main program here
                                            MainWindow Dashboard = new MainWindow(userID);
                                            Dashboard.Show();
                                        }
                                    
                                    } 
                                   
                                }


                               
                            }
                            else
                            {
                                MessageBox.Show("Invalid password.", "Login Alert");
                            }
                        });
            }
                        else
                        {
                                //using an application dispatcher
                                Application.Current.Dispatcher.Invoke(() =>
                                {
                                    MessageBox.Show("This user does not exist.", "Login Alert");
                                });

                            }


                        }
                }

                    dBConnector.MyConnection.Close();
                });
            }
            catch (Exception er)
            {
                MessageBox.Show($"An error has occurred while fetching the password: {er.Message}", "Login Alert");
            }

          
         
         
        }


        private void registerButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Register reg = new Register();
                reg.Show();
                Thread.Sleep(1000);
            });
        }
        public void getUserID(string username) 
        {
            string connectionString = "", selectCommand;
            SqlDataReader dataReader;
            SqlCommand command;


            selectCommand = $"SELECT userID FROM Users WHERE Username ='{username}';";//THIS SQL will only display the current registed user name and passwords

            command = new SqlCommand(selectCommand, dBConnector.MyConnection);
            dataReader = command.ExecuteReader();
            string output = "";
            while (dataReader.Read())
            {
                output = output + dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + "\n";
            }

            // MessageBox.Show(output);

            dataReader.Close();
            command.Dispose();
            dBConnector.MyConnection.Close();
        }



        //a function to retrive the hashed password string

        private string getHashedPassword(string password) 
        {

            using(SHA256 sha256= SHA256.Create()) 
            {
              var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
               return BitConverter.ToString(hashedBytes).Replace("-","").ToLower();   
            }
            Thread.Sleep(1000);
        }

        //register function
        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Register registerPage = new Register();
                registerPage.Show();
                Thread.Sleep(1000);
            });

        }
        //login function
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Login loginPage = new Login();
               loginPage.Show();
                Thread.Sleep(1000);
            });

        }


    }
}

﻿using ModuleLibrary;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Security.Cryptography;
using System;

namespace PROG6212_POE
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        public Register()
        {
            InitializeComponent();
        }
       

        //closing function
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }

        //register function
        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Register registerPage = new Register();
            registerPage.Show();

        }
        //login function
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Login loginPage = new Login();
            loginPage.Show();

        }


        private async void registerButton_Click(object sender, RoutedEventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = confirmPasswordTextBox.Password;
            DBConnector database = new DBConnector();//Instatiating the DBconnector custom class from custom library
            SqlDataReader dataReader;
            SqlCommand command;

            string hashedPassword;
            using (SHA256 sha256 = SHA256.Create()) 
            {

                //THISWILL SEND A SAMPLE HASH
               var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
              //this will retriev ethe hased password
               hashedPassword = BitConverter.ToString(hashedBytes).Replace("-","").ToLower();

                //printing the hashed password 

            }
            

           await Task.Run(() => {
           SqlDataReader dataReader;
               SqlCommand command;
           DBConnector database = new DBConnector();//INSTANTIATING THE  database class
                database.insertData(usernameTextBox.Text, hashedPassword);

                string selectCMD = "SELECT Username, Passwords FROM Users";

                //uSing the select statement to chech for registred users
                using(database.MyConnection) 
                {

                   command = new SqlCommand(selectCMD, database.MyConnection);
                   dataReader = command.ExecuteReader();

                   using  (dataReader = command.ExecuteReader()) 
                   {
                   
                   }
                    string output = "";

                    while (dataReader.Read()) 
                    {
                        output =output + dataReader.GetValue(0)+" - "+dataReader.GetValue(1);
                    }
                   Dispatcher.Invoke(() => { MessageBox.Show(output); });

                
                }

               dataReader.Close();
               command.Dispose();
               database.MyConnection.Close();

           });



        }
        //login button function
        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
          
            login.Show();
        }

        



    }
}

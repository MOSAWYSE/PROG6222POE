﻿using ModuleLibrary;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG6212_POE
{
    /// <summary>
    /// Interaction logic for SemesterDetails.xaml
    /// </summary>
    public partial class SemesterDetails : Window
    {
        public string moduleCode { get; set; }
        public string moduleName { get; set; }
        public int userId { get; set; } 
        public double classHours { get; set; }
        public string semesterStartDate { get; set; }

        public int semsterWeeks { get; set; }

        public List<SemesterDetails> Dashboard = new List<SemesterDetails>();
        public SemesterDetails()
        {
            InitializeComponent();
        }


        //exit button
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }


        //register function
        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Register registerPage = new Register();
                registerPage.Show();
                Thread.Sleep(1000);
            });

        }
        //login function
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Login loginPage = new Login();
                loginPage.Show();
                Thread.Sleep(1000);
            });

        }



        //display function method

        private void button1_Click(object sender, RoutedEventArgs e)
        {
                outputListview.ItemsSource = Dashboard;
            

        }

        //save button functionality
        private void button_Click(object sender, RoutedEventArgs e)
        {
            string userId = userIDTextbox.Text;
            int ID = Convert.ToInt32(userId);
            DBConnector database = new DBConnector();

            string selectCommand;
            SqlDataReader dataReader;
            SqlCommand command;


            selectCommand = $"SELECT moduleCode, semesterStartDate, semesterWeeks FROM SemesterData WHERE UserID ='{userId}'";//THIS SQL will only display the current logged in user semester details

            command = new SqlCommand(selectCommand, database.MyConnection);
            dataReader = command.ExecuteReader();
            string output = "", ModuleCode = "", startDate = "";

            int semesterWeeks = 0;
            //using the dispatcher to handle the ui operations
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (dataReader.Read())
            {
                ModuleCode = ModuleCode + dataReader.GetString(0);
                startDate = startDate + dataReader.GetString(1);
                semesterWeeks = semesterWeeks + dataReader.GetInt32(0);
                //  output = output + dataReader.GetValue(0) + " - " + dataReader.GetValue(1) + "\n" + dataReader.GetValue(2);

                //adding the data to the dashboard window
                Dashboard.Add(new SemesterDetails()
                {
                    moduleCode = ModuleCode,
                    semesterStartDate = startDate,
                    semsterWeeks = semesterWeeks


                });


              


                }


            });

            dataReader.Close();
            command.Dispose();
            database.MyConnection.Close();
        }
    }
}
